Privacy Policy

This Privacy Policy describes how your personal information is collected, used, and shared when you use Trello Collapse Lists (the “Extension”).

PERSONAL INFORMATION WE COLLECT

None - personal information is stored on the client and not sent to any first- or third-parties.

HOW DO WE USE YOUR PERSONAL INFORMATION?

We don't.

SHARING YOUR PERSONAL INFORMATION

We don't. 

DO NOT TRACK

We don't.

CHANGES
We may, but do not expect to, update this privacy policy from time to time in order to reflect, for example, changes to our practices or for other operational, legal or regulatory reasons.

CONTACT US
For more information about our privacy practices, if you have questions, or if you would like to make a complaint, please contact us by e-mail at webrender@gmail.com.